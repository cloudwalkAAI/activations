<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('login_model');
    }

    function verification(){
        if($this->session->userdata('sess_id')){
            $this->validatelogin( '' );
        }else{
            echo $this->login_model->checkuser( $this->input->post() );
            $this->validatelogin( '?inc=0' );
        }
    }

    function validatelogin( $a ){
        redirect(base_url().$a);
    }
}