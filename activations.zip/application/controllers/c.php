<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class c extends CI_Controller{
    public function __construct() {
        parent::__construct ();
        $this->load->model('update_model');
        $this->load->model('get_model');
    }

    public function index(){
        $data_cp['cp'] = $this->input->get('p');
        $data_cp['iddata'] = $this->input->get('i');
        $data_cp['change_pass'] = $this->get_model->check_account( $this->input->get('p'), $this->input->get('i') );
        $data['navigator'] = '';
        $data['content'] = $this->load->view('change_password', $data_cp, TRUE);
        $this->load->view('master_page', $data);
    }

    function cpass(){
        if( $this->input->post( 'npass' ) == $this->input->post( 'repass' ) ){
            $result = $this->update_model->upd_pass( $this->input->post() );
            $data_cp['qresult'] = $result;
            $data['navigator'] = '';
            $data['content'] = $this->load->view( 'password_result', $data_cp, TRUE );
            $this->load->view('master_page', $data);
        }else{
            redirect( base_url().'c?p='.$this->input->post('user_code').'&i='.$this->input->post('user_id').'&inv=1' );
        }
    }
}